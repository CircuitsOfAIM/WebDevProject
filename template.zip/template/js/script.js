//////////////////////////////////////////////////////////
// validation login
function validatelogin() {
    // username validation
    formvld = true;
    if (loginform.username.value == '') {
        document.getElementById('loginusererrspan').innerHTML = 'این فیلد نباید خالی باشد';
        document.getElementById('loginuserid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    if (loginform.username.value.length < 3 && loginform.username.value != '') {
        document.getElementById('loginusererrspan').innerHTML = 'نام کاربری نباید کمتر از 3 حرف باشد';
        document.getElementById('loginuserid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    // validation password
    if (loginform.password.value == '') {
        document.getElementById('loginpasserrspan').innerHTML = 'این فیلد نباید خالی باشد';
        document.getElementById('loginpassid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    return formvld;
}
// validation signup
function validatesignup() {
    // username validation
    formvld = true;
    if (signupform.username.value == '') {
        document.getElementById('signupusererrspan').innerHTML = 'این فیلد نباید خالی باشد';
        document.getElementById('signupuserid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    if (signupform.username.value.length < 3 && signupform.username.value != '') {
        document.getElementById('signupusererrspan').innerHTML = 'نام کاربری نباید کمتر از 3 حرف باشد';
        document.getElementById('signupuserid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    // validation password
    if (signupform.password.value == '') {
        document.getElementById('signuppasserrspan').innerHTML = 'این فیلد نباید خالی باشد';
        document.getElementById('signuppassid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    // validation tel
    if (signupform.telnumber.value=='') {
        document.getElementById('signuptelerrspan').innerHTML = 'این فیلد نباید خالی باشد';
        document.getElementById('signuptelid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    if (isNaN(signupform.telnumber.value)) {
        document.getElementById('signuptelerrspan').innerHTML = 'شماره تلفن باید عدد باشد';
        document.getElementById('signuptelid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    if (signupform.telnumber.value.length != 11 && signupform.telnumber.value != '') {
        document.getElementById('signuptelerrspan').innerHTML = 'شماره تلفن باید 11 رقم باشد';
        document.getElementById('signuptelid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    if (signupform.telnumber.value.charAt(0)!='0'&& signupform.telnumber.value != '') {
        document.getElementById('signuptelerrspan').innerHTML = 'شماره تلفن باید با 0 شروع شود';
        document.getElementById('signuptelid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }

    return formvld;
}
// validate sell addcase
function validateselladdcase(){
    formvld=true;
    // casetype
    if(sellform.casetype.value ==''){
        document.getElementById('casetypeerrid').innerHTML = "لطفا یکی از گزینه ها را انتخاب کنید"
        document.getElementById('casetypeid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    // // casearea
    if(sellform.casearea.value ==''){
        document.getElementById('caseareaerrid').innerHTML = "لطفا یکی از گزینه ها را انتخاب کنید"
        document.getElementById('caseareaid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    // // sellprice
    if (sellform.sellprice.value=='') {
        document.getElementById('sellpriceerrid').innerHTML = 'این فیلد نباید خالی باشد';
        document.getElementById('sellpriceid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    if (isNaN(sellform.sellprice.value)) {
        document.getElementById('sellpriceerrid').innerHTML = 'قیمت باید عدد باشد';
        document.getElementById('sellpriceid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    // // sellmeterage
    if (isNaN(sellform.meterage.value)) {
        document.getElementById('meterageerrid').innerHTML = 'متراژ باید عدد باشد';
        document.getElementById('meterageid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    if (sellform.meterage.value=='') {
        document.getElementById('meterageerrid').innerHTML = 'این فیلد نباید خالی باشد';
        document.getElementById('meterageid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    // // sellroomnum
    if (isNaN(sellform.roomnum.value)) {
        document.getElementById('roomnumerrid').innerHTML = 'تعداد خواب باید عدد باشد';
        document.getElementById('roomnumid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    if (sellform.roomnum.value=='') {
        document.getElementById('roomnumerrid').innerHTML = 'این فیلد نباید خالی باشد';
        document.getElementById('roomnumid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    // sellbulidyear
    if (isNaN(sellform.buildyear.value)) {
        document.getElementById('buildyearerrid').innerHTML = 'سال ساخت باید عدد باشد';
        document.getElementById('buildyearid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    if (sellform.buildyear.value=='') {
        document.getElementById('buildyearerrid').innerHTML = 'این فیلد نباید خالی باشد';
        document.getElementById('buildyearid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    // caseexp
    if (sellform.caseexp.value.length >200 && sellform.caseexp.value != '') {
        document.getElementById('caseexperrid').innerHTML = 'حداکثر کاراتر مجاز 200 است';
        document.getElementById('caseexpid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    return formvld
}
// validation rent form
function validaterentaddcase(){
    formvld=true;
    // casetype
    if(rentform.casetype.value ==''){
        document.getElementById('rentcasetypeerrid').innerHTML = "لطفا یکی از گزینه ها را انتخاب کنید"
        document.getElementById('rentcasetypeid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    // // casearea
    if(rentform.casearea.value ==''){
        document.getElementById('rentcaseareaerrid').innerHTML = "لطفا یکی از گزینه ها را انتخاب کنید"
        document.getElementById('rentcaseareaid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
        // // rahnprice
        if (rentform.rahnprice.value=='') {
            document.getElementById('rentrahnpriceerrid').innerHTML = 'این فیلد نباید خالی باشد';
            document.getElementById('rentrahnpriceid').style.boxShadow = '0 0 3px #D8000C';
            formvld = false;
        }
        if (isNaN(rentform.rahnprice.value)) {
            document.getElementById('rentrahnpriceerrid').innerHTML = 'قیمت باید عدد باشد';
            document.getElementById('rentrahnpriceid').style.boxShadow = '0 0 3px #D8000C';
            formvld = false;
        }
        // // rentprice
        if (rentform.rentprice.value=='') {
            document.getElementById('rentpriceerrid').innerHTML = 'این فیلد نباید خالی باشد';
            document.getElementById('rentpriceid').style.boxShadow = '0 0 3px #D8000C'
            formvld = false;
        }
        if (isNaN(rentform.rentprice.value)) {
            document.getElementById('rentpriceerrid').innerHTML = 'قیمت باید عدد باشد';
            document.getElementById('rentpriceid').style.boxShadow = '0 0 3px #D8000C'
            formvld = false;
        }
    // // sellmeterage
    if (isNaN(rentform.meterage.value)) {
        document.getElementById('rentmeterageerrid').innerHTML = 'متراژ باید عدد باشد';
        document.getElementById('rentmeterageid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    if (rentform.meterage.value=='') {
        document.getElementById('rentmeterageerrid').innerHTML = 'این فیلد نباید خالی باشد';
        document.getElementById('rentmeterageid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    // // sellroomnum
    if (isNaN(rentform.roomnum.value)) {
        document.getElementById('rentroomnumerrid').innerHTML = 'تعداد خواب باید عدد باشد';
        document.getElementById('rentroomnumid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    if (rentform.roomnum.value=='') {
        document.getElementById('rentroomnumerrid').innerHTML = 'این فیلد نباید خالی باشد';
        document.getElementById('rentroomnumid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    // sellbulidyear
    if (isNaN(rentform.buildyear.value)) {
        document.getElementById('rentbuildyearerrid').innerHTML = 'سال ساخت باید عدد باشد';
        document.getElementById('rentbuildyearid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    if (rentform.buildyear.value=='') {
        document.getElementById('rentbuildyearerrid').innerHTML = 'این فیلد نباید خالی باشد';
        document.getElementById('rentbuildyearid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    // caseexp
    if (rentform.caseexp.value.length >200 && sellform.caseexp.value != '') {
        document.getElementById('rentcaseexperrid').innerHTML = 'حداکثر کاراتر مجاز 200 است';
        document.getElementById('rentcaseexpid').style.boxShadow = '0 0 3px #D8000C'
        formvld = false;
    }
    return formvld
}
// editprofile validation
function validateeditprofile(){
        // username validation
        formvld = true;
        if (edirprofileform.username.value == '') {
            document.getElementById('editprofileusererrid').innerHTML = 'این فیلد نباید خالی باشد';
            document.getElementById('editprofileuserid').style.boxShadow = '0 0 3px #D8000C'
            formvld = false;
        }
        if (edirprofileform.username.value.length < 3 && edirprofileform.username.value != '') {
            document.getElementById('editprofileusererrid').innerHTML = 'نام کاربری نباید کمتر از 3 حرف باشد';
            document.getElementById('editprofileuserid').style.boxShadow = '0 0 3px #D8000C'
            formvld = false;
        }
        // validation password
        // if (edirprofileform.password.value == '') {
        //     document.getElementById('editprofilepasserrid').innerHTML = 'این فیلد نباید خالی باشد';
        //     document.getElementById('editprofilepassid').style.boxShadow = '0 0 3px #D8000C'
        //     formvld = false;
        // }
        // validation tel
        if (edirprofileform.telnumber.value=='') {
            document.getElementById('editprofiletelerrid').innerHTML = 'این فیلد نباید خالی باشد';
            document.getElementById('editprofiletelid').style.boxShadow = '0 0 3px #D8000C'
            formvld = false;
        }
        if (isNaN(edirprofileform.telnumber.value)) {
            document.getElementById('editprofiletelerrid').innerHTML = 'شماره تلفن باید عدد باشد';
            document.getElementById('editprofiletelid').style.boxShadow = '0 0 3px #D8000C'
            formvld = false;
        }
        if (edirprofileform.telnumber.value.length != 11 && edirprofileform.telnumber.value != '') {
            document.getElementById('editprofiletelerrid').innerHTML = 'شماره تلفن باید 11 رقم باشد';
            document.getElementById('editprofiletelid').style.boxShadow = '0 0 3px #D8000C'
            formvld = false;
        }
        if (edirprofileform.telnumber.value.charAt(0)!='0'&& edirprofileform.telnumber.value != '') {
            document.getElementById('editprofiletelerrid').innerHTML = 'شماره تلفن باید با 0 شروع شود';
            document.getElementById('editprofiletelid').style.boxShadow = '0 0 3px #D8000C'
            formvld = false;
        }
    
        return formvld;
}
// namayeyshe search;
function showsearch() {
    if (document.getElementById('advsearchid').style.display == "none") {
        document.getElementById('advsearchid').style.display = "inherit";
    }
    else {
        document.getElementById('advsearchid').style.display = "none";
    }
}
// namayeshe form rahn o ejare ya froosh
function showform(a) {
    if (a == 1) {
        document.getElementById('sellform').style.display = "inherit";
        document.getElementById('rentform').style.display = "none";
        document.getElementById('casesellbtnid').style.background = "#328cc1";
        document.getElementById('casesellbtnid').style.color = "#fff";
        document.getElementById('caserentbtnid').style.background = "#fff";
        document.getElementById('caserentbtnid').style.color = "#000";
    }
    else if (a == 2) {
        document.getElementById('rentform').style.display = "inherit";
        document.getElementById('sellform').style.display = "none";
        document.getElementById('caserentbtnid').style.background = "#328cc1";
        document.getElementById('caserentbtnid').style.color = "#fff";
        document.getElementById('casesellbtnid').style.background = "#fff";
        document.getElementById('casesellbtnid').style.color = "#000";
    }
}

// ///////////////////////////////////
mapboxgl.accessToken = 'pk.eyJ1IjoiYWxpcmV6YTIzYSIsImEiOiJjand0aWd2MWgyM3Y4NDNsZWV2cWRobDllIn0.8Wj0xYM_kS85O-Q-mxrV6g';
// 59.57281115091922, 36.302257194262
// 59.57688994607821, 36.30228354719891

var ll = new mapboxgl.LngLat(59.57281115091922, 36.302257194262);
var map = new mapboxgl.Map({
    container: 'map',
    style: 'mapbox://styles/mapbox/streets-v11',
    zoom: 14,
    center: ll
});

// markere abii rang ba ghabeliate drag
var marker = new mapboxgl.Marker({
    draggable: true
})
    .setLngLat([59.57281115091922, 36.302257194262])
    .addTo(map);

function onDragEnd() {
    var lngLat = marker.getLngLat();
    var coordinates = document.getElementById('coordinates');
    coordinates.style.display = 'block';
    coordinates.innerHTML = 'Longitude: ' + lngLat.lng + '<br />Latitude: ' + lngLat.lat;
}
// mokhtasaate noghteii ke marker rooye oon hasto mide
marker.on('dragend', onDragEnd);


//////////////////////////////////////////////////////////