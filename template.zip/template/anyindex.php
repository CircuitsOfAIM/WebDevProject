<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./template/css/style.css">
    <link rel="stylesheet" href="./template/fontawesome-free-5.7.2-web/css/all.css">
    <title>HOME</title>
</head>

<body>
    <div class="main" id="mainid">
        <div class="navbar">
            <div class="iconlogo">
                <a href="index.php?authstatus=signup">
                    <i class="fa fa-plus" title="افزودن مورد"></i>
                </a>
            </div>
            <div class="logoclass"><a href="index.php">اسکای لاین</a></div>
            <div class="menubutton">
                <a href="index.php?authstatus=signup">ثبت نام</a>
                <a href="index.php?authstatus=login" class="navloginbtn">ورود</a>
            </div>
        </div>
        <div class="firstlayercontent">

            <div class="row">
                <div class="content">
                <?php
                    require(template::getview('anyindexview'));
                    ?>
                </div>
            </div>
        </div>
    </div>

    <script src="js/script.js"></script>
</body>

</html>